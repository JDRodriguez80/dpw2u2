<nav>
    <ul>
        <li>
            <a href="../main.php">Inicio</a>
            <a href="/preInscripcion.php">Pre-inscribir asignatura</a>
            <a href="/consultarInscripcionControl.php">Consultar inscripciónes </a>
            <a href="../salir.php">Salir</a>
        </li>
    </ul>
</nav>