<nav>
    <ul>
        <li>
            <a href="../main.php">Inicio</a>
            <a href="/preInscripcion.php">Pre-inscribir asignatura</a>
            <a href="/consultarInscripcion.php">Consultar inscripción</a>

            <a href="../salir.php">Salir</a>
        </li>
    </ul>
</nav>