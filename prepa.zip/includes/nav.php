<nav>
    <ul>
        <li><a href="../index.php">Inicio</a>
            <a href="../registro.php">Registrarse</a>
            <a href="../inicioSesion.php">Iniciar sesión</a>
        </li>
    </ul>
</nav>